
const PRODUCTS = [
  ["iPhone 8","95 000","115 000"],["iPhone 8 Plus","125 000","145 000"],
  ["iPhone X","150 000","175 000"],["iPhone XR","155 000","180 000"],
  ["iPhone 11","185 000","210 000"],["iPhone 12","215 000","240 000"],
  ["iPhone 13","295 000","330 000"],["iPhone 14","360 000","400 000"],
  ["iPhone 14 Pro","480 000","550 000"],["iPhone 14 Pro Max","520 000","600 000"],
  ["iPhone 15","535 000","620 000"],["iPhone 15 Plus","580 000","670 000"]
];

const KEY = "ishop_prices_v1";
const ADMIN_OK = "ishop_admin_demo";

function loadPrices(){
  try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch(e){ return {}; }
}
function savePrices(p){ localStorage.setItem(KEY, JSON.stringify(p)); }

function normalize(s){ return s.toLowerCase().replace(/\s+/g," ").trim(); }
function findProduct(name){
  const n = normalize(name);
  return PRODUCTS.find(p => normalize(p[0]) === n) ||
         PRODUCTS.find(p => normalize(p[0]).includes(n) || n.includes(normalize(p[0])));
}
function money(n){ return Number(n).toLocaleString("fr-FR") + " FCFA"; }

function applyPriceCommand(command){
  const text = normalize(command);
  const match = text.match(/(?:mets|met|change|modifie|fixe|mettre)\s+(?:le\s+prix\s+de\s+)?(.+?)\s+(?:a|à)\s+([0-9][0-9 .]*)/i);
  if(!match) return {ok:false,msg:"Exemple : « mets le prix de iPhone 13 à 300000 »."};
  const product = findProduct(match[1]);
  const raw = match[2].replace(/[ .]/g,"");
  const price = parseInt(raw,10);
  if(!product || !price) return {ok:false,msg:"Je n’ai pas compris le modèle ou le prix."};
  const prices = loadPrices();
  prices[product[0]] = prices[product[0]] || {};
  prices[product[0]].single = price;
  savePrices(prices);
  return {ok:true,msg:`Prix de ${product[0]} mis à ${money(price)}.`};
}

function adminPanel(){
  document.body.innerHTML = `
  <div style="min-height:100vh;background:#070b10;color:#fff;font-family:Arial;padding:30px">
    <div style="max-width:900px;margin:auto">
      <h1 style="color:#f5c542">Assistant propriétaire — iShop</h1>
      <p style="color:#aab5c4">Dis une commande comme : <b>« mets le prix de iPhone 13 à 300000 »</b>.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:20px 0">
        <input id="cmd" placeholder="Écris ta commande..." style="flex:1;min-width:250px;padding:15px;border-radius:10px;border:0">
        <button id="go" style="padding:15px 20px;border:0;border-radius:10px;background:#f5c542;font-weight:bold">Modifier</button>
      </div>
      <div id="result" style="padding:15px;border-radius:10px;background:#111821;margin-bottom:25px"></div>
      <h2>Prix personnalisés</h2>
      <div id="list"></div>
      <p style="margin-top:30px;color:#7f8b9a;font-size:13px">
        Démo locale : les modifications sont enregistrées dans ce navigateur.
        Pour un site public, il faut connecter ce panneau à une vraie authentification serveur et une base de données.
      </p>
      <a href="index.html" style="color:#f5c542">← Retour à la boutique</a>
    </div>
  </div>`;
  const render = () => {
    const p = loadPrices();
    document.getElementById("list").innerHTML = PRODUCTS.map(x => {
      const custom = p[x[0]]?.single;
      return `<div style="background:#111821;border:1px solid #273241;border-radius:10px;padding:12px;margin:8px 0">
        <b>${x[0]}</b> — ${custom ? money(custom) : x[1]+" / "+x[2]+" FCFA"}
      </div>`;
    }).join("");
  };
  document.getElementById("go").onclick = () => {
    const r = applyPriceCommand(document.getElementById("cmd").value);
    document.getElementById("result").textContent = r.msg;
    if(r.ok) document.getElementById("cmd").value = "";
    render();
  };
  render();
}

if(location.pathname.endsWith("/admin.html")){
  const pass = prompt("Accès propriétaire — mot de passe de démonstration :");
  if(pass !== ADMIN_OK){
    document.body.innerHTML = "<h2 style='font-family:Arial;text-align:center;margin-top:80px'>Accès refusé.</h2>";
  } else adminPanel();
}
